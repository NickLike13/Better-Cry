Ciao Dano, sono un grande fan. Ho sempre sognato di essere in un episodio della virus saga.
Metti la cartella sul Desktop ed esegui bettercry.
NOTA: Non sono un profesionista ed è un malware molto semplice da fermare.
Se problemi con collegamento modifica la destinazione "C:\Users\(tuo nome utente)\Desktop\BetterCry\files\files importanti\malwere.bat"
P.S: ho fatto un malware segreto che si nasconde tra le cartelle, buona fortuna a trovarlo(se vuoi)
Buona Fortuna!